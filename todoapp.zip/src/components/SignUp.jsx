import React, { useContext, useState } from 'react';
import TodoContext from '../context/TodoContext'
function SignUp(props) {
    const [formData, setFormData]=useState({
        username: "",
        email: "",
        password: ""
    })
    const {message, register} = useContext(TodoContext);
    const handleChange = (e) =>{
        const {name, value} = e.target;
        setFormData((prev)=>({
            ...prev,
            [name]: value,
            role: "user"
        }))
    }

    const onRegister = (e) =>{
        e.preventDefault();
        register(formData);
    }
    return (
        <>
           <form className="register" id="register-form">
                                    <div className="mb-4">
                                        <label className="form-label" htmlFor="username">Username</label>
                                        <input className="form-control" type="text" name="username" id="username" value={formData.username} onChange={handleChange} />
                                    </div>
                                    <div className="mb-4">
                                        <label className="form-label" htmlFor="email">Email</label>
                                        <input className="form-control" type="email" name="email" id="email" value={formData.email} onChange={handleChange}/>
                                    </div>
                                    <div className="mb-4">
                                        <label className="form-label" htmlFor="password">Password</label>
                                        <input className="form-control" type="password" name="password" id="password" autoComplete='off' value={formData.password} onChange={handleChange}/>
                                    </div>
                                    <p>{message}</p>
                                    <button className="btn bg-primary text-white px-5 py-2" onClick={onRegister}>Register</button>
                                </form>   
        </>
    );
}

export default SignUp;