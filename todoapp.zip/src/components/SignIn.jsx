import React, { useContext, useState } from "react";
import TodoContext from "../context/TodoContext";

function SignIn(props) {
    const [formData, setFormData]=useState({
        username: "",
        email: "",
        password: ""
    })
    const {message, login} = useContext(TodoContext);
    const handleChange = (e) =>{
        const {name, value} = e.target;
        setFormData((prev)=>({
            ...prev,
            [name]: value,
        }))
    }

    const onLogin = (e) =>{
        e.preventDefault();
        login(formData);
    }
  
  return (
    <>
      <form className="login" id="login-form">
        <div className="mb-4">
          <label className="form-label" htmlFor="username">
            Username or Email
          </label>
          <input
            className="form-control"
            type="text"
            name="email"
            id="username"
            onChange={handleChange}
          />
        </div>
        <div className="mb-4">
          <label className="form-label" htmlFor="username">
            Password
          </label>
          <input
            className="form-control"
            type="password"
            name="password"
            id="password"
            autoComplete="off"
            onChange={handleChange}
          />
        </div>
        <p>{message}</p>
        <button className="btn bg-primary text-white px-5 py-2" onClick={onLogin}>Login</button>
        <div className="mt-3">
          <p>
            Forgot Username/Password ? <br />
            <a className="text-info" href="#password-reset">             
              Click here</a> to reset.
          </p>
        </div>
      </form>
    </>
  );
}

export default SignIn;
